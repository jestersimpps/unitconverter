  function LogCtrl($scope, $log) {
    $scope.$log = $log;
    $scope.message = 'Hello World!';
  }